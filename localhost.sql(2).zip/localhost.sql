-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 09, 2015 at 12:53 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbhospital`
--
CREATE DATABASE `dbhospital` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dbhospital`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_assistant`
--

CREATE TABLE IF NOT EXISTS `tbl_assistant` (
  `id` bigint(16) NOT NULL,
  `fname` varchar(64) NOT NULL,
  `mname` varchar(64) NOT NULL,
  `lname` varchar(64) NOT NULL,
  `address` varchar(64) NOT NULL,
  `birthdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `gender` varchar(64) NOT NULL,
  `contact_no` varchar(64) NOT NULL,
  `doctor_id` bigint(64) NOT NULL,
  `user_id` bigint(64) NOT NULL,
  `img` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_assistant`
--

INSERT INTO `tbl_assistant` (`id`, `fname`, `mname`, `lname`, `address`, `birthdate`, `gender`, `contact_no`, `doctor_id`, `user_id`, `img`) VALUES
(10001, 'Payton', 'M', 'Sawyer', 'Smallville', '2015-01-26 01:53:39', 'Female', '+09121234321', 10001, 2, 'staff.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_doctor`
--

CREATE TABLE IF NOT EXISTS `tbl_doctor` (
  `id` bigint(64) NOT NULL,
  `fname` varchar(64) NOT NULL,
  `mname` varchar(64) NOT NULL,
  `lname` varchar(64) NOT NULL,
  `specialist` varchar(255) NOT NULL,
  `address` varchar(64) NOT NULL,
  `gender` varchar(64) NOT NULL,
  `contact_no` varchar(64) NOT NULL,
  `birthdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_id` bigint(64) NOT NULL,
  `img` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_doctor`
--

INSERT INTO `tbl_doctor` (`id`, `fname`, `mname`, `lname`, `specialist`, `address`, `gender`, `contact_no`, `birthdate`, `user_id`, `img`) VALUES
(10001, 'John', 'M', 'Doe', 'Pediatrician', 'Makati City', 'Male', '+09121234321', '2015-01-26 01:01:15', 3, 'doctor.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_patient`
--

CREATE TABLE IF NOT EXISTS `tbl_patient` (
  `id` bigint(12) NOT NULL,
  `fname` varchar(64) NOT NULL,
  `mname` varchar(64) NOT NULL,
  `lname` varchar(64) NOT NULL,
  `address` varchar(64) NOT NULL,
  `birthdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `gender` varchar(64) NOT NULL,
  `contact_no` varchar(64) NOT NULL,
  `user_id` bigint(64) NOT NULL,
  `img` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_patient`
--

INSERT INTO `tbl_patient` (`id`, `fname`, `mname`, `lname`, `address`, `birthdate`, `gender`, `contact_no`, `user_id`, `img`) VALUES
(10001, 'Lucas', 'P', 'Scott', 'Three Hill', '2015-01-26 01:17:22', 'Male', '+09121234321', 4, 'client.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_schedule`
--

CREATE TABLE IF NOT EXISTS `tbl_schedule` (
  `id` bigint(16) NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(16) NOT NULL,
  `doctor_id` bigint(16) NOT NULL,
  `assistant_id` bigint(16) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(64) NOT NULL,
  `condition` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10002 ;

--
-- Dumping data for table `tbl_schedule`
--

INSERT INTO `tbl_schedule` (`id`, `patient_id`, `doctor_id`, `assistant_id`, `date`, `status`, `condition`) VALUES
(10001, 10001, 10001, 10001, '2015-01-27 02:22:31', 'Scheduled', 'For check up. Fever');

-- --------------------------------------------------------

--
-- Table structure for table `user_tbl`
--

CREATE TABLE IF NOT EXISTS `user_tbl` (
  `user_id` int(12) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `salt` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `usertype` int(6) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `user_tbl`
--

INSERT INTO `user_tbl` (`user_id`, `username`, `password`, `salt`, `name`, `usertype`) VALUES
(1, 'admin', '9833b4a6c8034e56af4200640e60e71e94542e821cb6868401d574401eb96f60', '487fcb2864f928d8', 'Admin User', 4),
(2, 'staff', '9833b4a6c8034e56af4200640e60e71e94542e821cb6868401d574401eb96f60', '487fcb2864f928d8', 'Staff User', 2),
(3, 'doctor', '9833b4a6c8034e56af4200640e60e71e94542e821cb6868401d574401eb96f60', '487fcb2864f928d8', 'Doctor User', 3),
(4, 'client', '9833b4a6c8034e56af4200640e60e71e94542e821cb6868401d574401eb96f60', '487fcb2864f928d8', 'Client User', 1);
